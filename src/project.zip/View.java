/**
 * Mancala : View - interface
 * Interface for all views
 * @author Peter Yulong Chen, Paul Diaz, Branden Anderson, Brandon Trinh
 */
public interface View {
    void update(int i);
}
